#!/usr/bin/env python3
"""
Clean-room verifier for the five-packet global certificate audit.

This verifier intentionally uses only:
  * the five ZIP paths supplied on the command line;
  * Python's standard library;
  * files it creates in the requested output directory and a fresh temporary directory.

It does not treat the candidate-final packet as an independent source of mathematical
objects.  Candidate-final data are parsed only as claims to compare against the four
source packets.  The verifier halts with Decision G when an essential exact source
object cannot be regenerated from the four source packets.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import locale
import math
import os
import platform
import random
import re
import shutil
import stat
import sys
import tempfile
import zipfile
from collections import Counter, defaultdict
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path, PurePosixPath
from typing import Any

EXPECTED_HASHES = {
    "source_primal": "50817a80ec3e13832e682e2215c2d511458542101d21ce8474eac0e6ba6489a1",
    "source_root": "40164cc6d65601053ae30dfd63fad7bc6cd662141d4e28b2ebd47774571f0fc7",
    "source_active": "1f7abc5024948777850335f7cb422c58f60c9efa64e9763038d4454b5ee1c16c",
    "source_full_primal": "86475b452e86e93047937cd267551bffac7a08c80c87f8df64623bbc2ea14974",
    "candidate_final": "cce1bde9bb54f2bcd1e7d2be61c91256ce9cbd8c529ae1000e1dd2d948df2e87",
}
SEED = 0
DECISION = "G. PACKET INCOMPLETE FOR CLEAN-ROOM VERIFICATION"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def json_dump(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def safe_member_name(name: str) -> bool:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts:
        return False
    if name.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", name):
        return False
    return True


def parse_sha256sums(text: str) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^([0-9a-fA-F]{64})\s+\*?(.+)$", line)
        if not m:
            raise ValueError(f"Malformed SHA256SUMS line: {raw!r}")
        out.append({"sha256": m.group(1).lower(), "filename": m.group(2)})
    return out


def make_read_only_tree(root: Path) -> None:
    for path in sorted(root.rglob("*"), reverse=True):
        if path.is_file():
            path.chmod(stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
        elif path.is_dir():
            path.chmod(
                stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR |
                stat.S_IRGRP | stat.S_IXGRP |
                stat.S_IROTH | stat.S_IXOTH
            )
    root.chmod(
        stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR |
        stat.S_IRGRP | stat.S_IXGRP |
        stat.S_IROTH | stat.S_IXOTH
    )


def audit_zip(role: str, path: Path, extraction_root: Path) -> tuple[dict[str, Any], dict[str, bytes]]:
    result: dict[str, Any] = {
        "role": role,
        "input_path_basename": path.name,
        "top_level_sha256": sha256_file(path),
        "expected_top_level_sha256": EXPECTED_HASHES[role],
    }
    result["top_level_hash_match"] = (
        result["top_level_sha256"] == result["expected_top_level_sha256"]
    )
    members: dict[str, bytes] = {}
    member_rows: list[dict[str, Any]] = []
    duplicate_names: list[str] = []
    traversal: list[str] = []
    invalid_utf8: list[str] = []
    line_ending_issues: list[dict[str, Any]] = []

    with zipfile.ZipFile(path, "r") as archive:
        infos = archive.infolist()
        counts = Counter(info.filename for info in infos)
        duplicate_names = sorted(name for name, count in counts.items() if count > 1)
        for info in infos:
            name = info.filename
            if not safe_member_name(name):
                traversal.append(name)
                continue
            data = archive.read(info)
            members[name] = data
            row = {
                "filename": name,
                "compressed_bytes": info.compress_size,
                "uncompressed_bytes": info.file_size,
                "member_sha256": sha256_bytes(data),
                "crc32_hex": f"{info.CRC:08x}",
            }
            member_rows.append(row)
            if name.lower().endswith((".txt", ".json", ".tsv", ".csv", ".md", ".py")):
                try:
                    data.decode("utf-8")
                except UnicodeDecodeError:
                    invalid_utf8.append(name)
                crlf = data.count(b"\r\n")
                lf_total = data.count(b"\n")
                lone_cr = data.count(b"\r") - crlf
                if lone_cr or (crlf and lf_total > crlf):
                    line_ending_issues.append({
                        "filename": name,
                        "crlf": crlf,
                        "lf_total": lf_total,
                        "lone_cr": lone_cr,
                    })

        result["zip_test_result"] = archive.testzip()

    result["members"] = member_rows
    result["member_count"] = len(member_rows)
    result["duplicate_filenames"] = duplicate_names
    result["path_traversal_members"] = traversal
    result["invalid_utf8_members"] = invalid_utf8
    result["line_ending_issues"] = line_ending_issues

    content_groups: dict[str, list[str]] = defaultdict(list)
    for row in member_rows:
        content_groups[row["member_sha256"]].append(row["filename"])
    result["duplicate_content_groups"] = [
        {"sha256": digest, "filenames": names}
        for digest, names in sorted(content_groups.items())
        if len(names) > 1
    ]

    sha_manifest_status: dict[str, Any] = {
        "present": "SHA256SUMS.txt" in members,
        "entries": [],
        "mismatches": [],
        "missing_members": [],
    }
    if "SHA256SUMS.txt" in members:
        entries = parse_sha256sums(members["SHA256SUMS.txt"].decode("utf-8"))
        sha_manifest_status["entries"] = entries
        for entry in entries:
            filename = entry["filename"]
            if filename not in members:
                sha_manifest_status["missing_members"].append(filename)
                continue
            actual = sha256_bytes(members[filename])
            if actual != entry["sha256"]:
                sha_manifest_status["mismatches"].append({
                    "filename": filename,
                    "expected": entry["sha256"],
                    "actual": actual,
                })
    result["sha256sums_audit"] = sha_manifest_status

    json_manifest_status: dict[str, Any] = {
        "present": "MANIFEST.json" in members,
        "entries": [],
        "mismatches": [],
        "missing_members": [],
    }
    if "MANIFEST.json" in members:
        manifest = json.loads(members["MANIFEST.json"].decode("utf-8"))
        entries = manifest.get("files", [])
        json_manifest_status["entries"] = entries
        for entry in entries:
            filename = entry.get("filename", entry.get("name"))
            if filename not in members:
                json_manifest_status["missing_members"].append(filename)
                continue
            actual_hash = sha256_bytes(members[filename])
            actual_size = len(members[filename])
            if actual_hash != entry.get("sha256") or actual_size != int(entry.get("bytes")):
                json_manifest_status["mismatches"].append({
                    "filename": filename,
                    "manifest_sha256": entry.get("sha256"),
                    "actual_sha256": actual_hash,
                    "manifest_bytes": entry.get("bytes"),
                    "actual_bytes": actual_size,
                })
    result["json_manifest_audit"] = json_manifest_status

    extract_dir = extraction_root / role
    extract_dir.mkdir(parents=True, exist_ok=False)
    for row in member_rows:
        name = row["filename"]
        target = extract_dir / PurePosixPath(name)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(members[name])
    make_read_only_tree(extract_dir)
    result["read_only_extraction_subdir"] = f"read_only_packets/{role}"

    fatal_integrity = (
        not result["top_level_hash_match"]
        or result["zip_test_result"] is not None
        or bool(duplicate_names)
        or bool(traversal)
        or bool(invalid_utf8)
        or bool(line_ending_issues)
        or bool(sha_manifest_status["mismatches"])
        or bool(sha_manifest_status["missing_members"])
        or bool(json_manifest_status["mismatches"])
        or bool(json_manifest_status["missing_members"])
    )
    result["fatal_integrity_defect"] = fatal_integrity
    return result, members


def parse_tsv(text: str) -> list[dict[str, str]]:
    return list(csv.DictReader(text.splitlines(), delimiter="\t"))


def check_matrix_index_grid(rows: list[dict[str, str]], expected_n: int) -> dict[str, Any]:
    pairs = [(int(row["row"]), int(row["col"])) for row in rows]
    expected = {(i, j) for i in range(expected_n) for j in range(expected_n)}
    actual = set(pairs)
    return {
        "expected_dimension": expected_n,
        "row_count": len(rows),
        "duplicate_indices": sorted([list(x) for x, c in Counter(pairs).items() if c > 1]),
        "missing_indices_count": len(expected - actual),
        "extra_indices_count": len(actual - expected),
        "complete_dense_grid": actual == expected and len(rows) == expected_n * expected_n,
    }


def fixed_arithmetic_replay(root_obj: dict[str, Any]) -> dict[str, Any]:
    a = root_obj["arithmetic"]
    u = int(a["u"])
    v = int(a["v"])
    H2 = int(a["H2"])
    delta = v - 14 * u
    R_H = H2 - 14 * u
    basic = {
        "u": u,
        "v": v,
        "H2": H2,
        "delta_regenerated": delta,
        "R_H_regenerated": R_H,
        "delta_packet": int(a["delta"]),
        "R_H_packet": int(a["R_H"]),
        "gcd_regenerated": math.gcd(u, v),
        "conditions": {
            "delta_equals_packet": delta == int(a["delta"]),
            "R_H_equals_packet": R_H == int(a["R_H"]),
            "zero_lt_delta_lt_RH_lt_u": 0 < delta < R_H < u,
            "14u_le_H2_lt_15u": 14 * u <= H2 < 15 * u,
            "gcd_u_v_is_one": math.gcd(u, v) == 1,
        },
    }

    # Derive transition breakpoints directly from residue arithmetic.
    # n(x)=15 iff x<=R_H, carry e(x)=1 iff x+delta>=u,
    # next residue y=x+delta-eu, m(x)=15 iff y<=R_H.
    derived_intervals = [
        {
            "start": 0,
            "end": R_H - delta,
            "transition": [15, 0, 15],
            "reason": "x<=R_H; x+delta<u; x+delta<=R_H",
        },
        {
            "start": R_H - delta + 1,
            "end": u - delta - 1,
            "transition": [15, 0, 14],
            "reason": "x<=R_H; x+delta<u; x+delta>R_H",
        },
        {
            "start": u - delta,
            "end": R_H,
            "transition": [15, 1, 15],
            "reason": "x<=R_H; x+delta>=u; x+delta-u<=R_H",
        },
        {
            "start": R_H + 1,
            "end": u - 1,
            "transition": [14, 1, 15],
            "reason": "x>R_H; x+delta>=u; x+delta-u<=R_H",
        },
    ]
    packet_intervals = []
    for label, endpoints in a["intervals"].items():
        packet_intervals.append({
            "start": int(endpoints[0]),
            "end": int(endpoints[1]),
            "transition": [int(x) for x in label.split(",")],
        })
    derived_tuples = [
        (x["start"], x["end"], tuple(x["transition"])) for x in derived_intervals
    ]
    packet_tuples = [
        (x["start"], x["end"], tuple(x["transition"])) for x in packet_intervals
    ]
    partition_ok = (
        derived_intervals[0]["start"] == 0
        and derived_intervals[-1]["end"] == u - 1
        and all(
            derived_intervals[i]["end"] + 1 == derived_intervals[i + 1]["start"]
            for i in range(3)
        )
        and all(x["start"] <= x["end"] for x in derived_intervals)
    )
    basic["derived_residue_intervals"] = derived_intervals
    basic["packet_residue_intervals"] = packet_intervals
    basic["partition_verified_without_enumeration"] = partition_ok
    basic["packet_interval_match"] = derived_tuples == packet_tuples
    basic["automaton_regenerated"] = [x["transition"] for x in derived_intervals]
    basic["automaton_exact_match"] = (
        basic["automaton_regenerated"]
        == [[15, 0, 15], [15, 0, 14], [15, 1, 15], [14, 1, 15]]
    )
    basic["verified"] = (
        all(basic["conditions"].values())
        and partition_ok
        and basic["packet_interval_match"]
        and basic["automaton_exact_match"]
    )
    return basic


def polynomial_system_audit(text: str, center_rows: list[dict[str, str]]) -> dict[str, Any]:
    lines = text.splitlines()
    var_line = next((line for line in lines if line.startswith("c1, ")), None)
    if var_line is None:
        # The variable list is the first nonempty line after "Variable order:"
        for i, line in enumerate(lines):
            if line.strip() == "Variable order:" and i + 1 < len(lines):
                var_line = lines[i + 1].strip()
                break
    variables = [v.strip() for v in (var_line or "").split(",") if v.strip()]
    equation_numbers = []
    equations = []
    for line in lines:
        m = re.match(r"^F(\d+)\s*=\s*(.+)$", line)
        if m:
            equation_numbers.append(int(m.group(1)))
            equations.append(m.group(2))
    center_variables = [row["variable"] for row in center_rows]
    return {
        "variable_count": len(variables),
        "variables": variables,
        "equation_count": len(equations),
        "equation_numbers": equation_numbers,
        "equation_sequence_is_1_to_37": equation_numbers == list(range(1, 38)),
        "center_row_count": len(center_rows),
        "center_variable_order_match": variables == center_variables,
        "all_equations_nonempty": all(bool(e.strip()) for e in equations),
        "forbidden_factor_text_occurrences": {
            "lambda_equals_zero": text.count("lam=0"),
            "one_plus_tau_squared": text.count("1+tau**2"),
        },
        "parsed": len(variables) == 37 and len(equations) == 37,
    }


def source_functional_completeness(
    source_members: dict[str, dict[str, bytes]],
    candidate_members: dict[str, bytes],
) -> dict[str, Any]:
    candidate_name = "source_functional.json"
    if candidate_name not in candidate_members:
        return {
            "complete": False,
            "fatal_reason": "candidate-final packet itself lacks source_functional.json",
        }
    candidate = json.loads(candidate_members[candidate_name].decode("utf-8"))
    source_member_names = sorted(
        f"{role}:{name}" for role, members in source_members.items() for name in members
    )
    direct_source_objects = [
        item for item in source_member_names
        if "source_functional" in item.lower()
    ]

    candidate_values = {
        "S_numerator": str(candidate["S"]["numerator"]),
        "S_denominator": str(candidate["S"]["denominator"]),
        "G0_numerator": str(candidate["G0"]["numerator"]),
        "G0_denominator": str(candidate["G0"]["denominator"]),
    }
    for i, item in enumerate(candidate["E"], start=1):
        candidate_values[f"E{i}_numerator"] = str(item["numerator"])
        candidate_values[f"E{i}_denominator"] = str(item["denominator"])

    text_sources: dict[str, str] = {}
    for role, members in source_members.items():
        for name, data in members.items():
            if name.lower().endswith((".txt", ".json", ".tsv", ".csv", ".md")):
                text_sources[f"{role}:{name}"] = data.decode("utf-8", errors="replace")

    value_occurrences: dict[str, list[str]] = {}
    for label, value in candidate_values.items():
        value_occurrences[label] = sorted(
            source_name for source_name, text in text_sources.items() if value in text
        )

    reduced_checks = {}
    for label in ("S", "G0"):
        item = candidate[label]
        reduced_checks[label] = math.gcd(
            int(item["numerator"]), int(item["denominator"])
        ) == 1
    for i, item in enumerate(candidate["E"], start=1):
        reduced_checks[f"E{i}"] = math.gcd(
            int(item["numerator"]), int(item["denominator"])
        ) == 1

    # The source polynomial system explicitly says stationarity uses E1/Ej.
    ratio_only_declaration = []
    for source_name, text in text_sources.items():
        if "Stationarity rows use (E1/Ej)*PhiHat_j-PhiHat_1." in text:
            ratio_only_declaration.append(source_name)

    # Exact S and G0 do not occur in the four source packets.
    S_absent = not value_occurrences["S_numerator"]
    G0_absent = not value_occurrences["G0_numerator"]
    complete = bool(direct_source_objects) and not S_absent and not G0_absent
    return {
        "complete": complete,
        "candidate_claim_file": candidate_name,
        "candidate_values_reduced": reduced_checks,
        "direct_source_functional_objects_in_first_four_packets": direct_source_objects,
        "candidate_exact_value_occurrences_in_first_four_packets": value_occurrences,
        "ratio_only_stationarity_declarations": ratio_only_declaration,
        "S_exact_source_absent": S_absent,
        "G0_exact_source_absent": G0_absent,
        "mathematical_underdetermination": (
            "The first four packets encode stationarity through E1/Ej ratios and report "
            "rho at the isolated root, but do not supply exact S and G0. Ratios determine "
            "E only up to scale. For arbitrary nonzero scale a and arbitrary S, setting "
            "G0 = S*rho - a*(E_ratio_vector dot c*) preserves the reported rho. Therefore "
            "the exact source functional is not uniquely recoverable."
        ),
        "candidate_final_usage_rule": (
            "source_functional.json was parsed only as a candidate claim; it was not "
            "accepted as an independent regeneration source."
        ),
        "fatal_missing_objects": [
            "exact S from a non-candidate source packet",
            "exact G0 from a non-candidate source packet",
            "a non-candidate exact source-functional specification binding E1..E5 to S and G0",
        ],
    }


def write_required_first_output(path: Path, statuses: dict[str, str], decision: str) -> str:
    ordered = [
        "Clean-room directory created",
        "No hidden build artifacts used",
        "All five top-level hashes verified",
        "All internal manifests verified",
        "Canonical schema constructed",
        "Fixed arithmetic independently verified",
        "Automaton independently reconstructed",
        "Source functional independently verified",
        "Rotation polynomial system parsed",
        "Krawczyk inclusion regenerated",
        "Independent interval-Newton check",
        "Root uniqueness independently verified",
        "Active completion reconstructed from S",
        "Active kernel identities independently verified",
        "All sixteen state matrices regenerated",
        "All interval positivity proofs regenerated",
        "Only two intended singular matrices found",
        "Both nullities independently verified",
        "All 44 finite slacks regenerated",
        "w_3 ambiguity resolved",
        "Dual weights independently reconstructed",
        "K-stationarity symbolically verified",
        "All five c-stationarity reductions verified",
        "Complementary slackness independently verified",
        "Complete Lagrangian generated programmatically",
        "Dual constant independently derived",
        "Primal-dual equality independently verified",
        "Objective interval regenerated",
        "Target uniqueness independently verified",
        "Auxiliary-completion dimensions verified",
        "Schur induction mechanically checked",
        "Support geometry programmatically checked",
        "Two-path consistency checks passed",
        "Executable verifier created",
        "Clean-room verification ZIP created",
        "Formal certificate mathematically supported",
    ]
    lines = [f"{key}: {statuses.get(key, 'NOT RUN')}" for key in ordered]
    lines.append(f"Decision: {decision}")
    text = "\n".join(lines) + "\n"
    path.write_text(text, encoding="utf-8")
    return text


def build_argument_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser()
    p.add_argument("--source-primal", required=True, type=Path)
    p.add_argument("--source-root", required=True, type=Path)
    p.add_argument("--source-active", required=True, type=Path)
    p.add_argument("--source-full-primal", required=True, type=Path)
    p.add_argument("--candidate-final", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    return p


def main() -> int:
    args = build_argument_parser().parse_args()
    random.seed(SEED)
    getcontext().prec = 200

    output = args.output.resolve()
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=False)
    work_root = Path(tempfile.mkdtemp(prefix="clean_room_global_verify_")).resolve()
    extraction_root = work_root / "read_only_packets"
    extraction_root.mkdir()

    role_paths = {
        "source_primal": args.source_primal.resolve(),
        "source_root": args.source_root.resolve(),
        "source_active": args.source_active.resolve(),
        "source_full_primal": args.source_full_primal.resolve(),
        "candidate_final": args.candidate_final.resolve(),
    }
    for role, path in role_paths.items():
        if not path.is_file():
            raise FileNotFoundError(f"{role}: {path}")

    script_hash = sha256_file(Path(__file__).resolve())
    environment = {
        "operating_system": platform.platform(),
        "python_version": sys.version,
        "python_implementation": platform.python_implementation(),
        "integer_backend": "CPython arbitrary-precision int",
        "rational_backend": "fractions.Fraction (exact)",
        "decimal_backend": "decimal.Decimal",
        "decimal_precision": getcontext().prec,
        "decimal_rounding_mode": str(getcontext().rounding),
        "interval_backend": "NOT INITIALIZED; audit halted at source-completeness gate",
        "process_locale": locale.setlocale(locale.LC_ALL, None),
        "filesystem_encoding": sys.getfilesystemencoding(),
        "deterministic_random_seed": SEED,
        "verifier_source_sha256": script_hash,
        "fresh_temporary_working_directory": "<fresh-ephemeral-directory-created>",
        "input_paths_used": {role: path.name for role, path in role_paths.items()},
        "other_mnt_data_files_used": [],
    }

    zip_audits: dict[str, Any] = {}
    member_maps: dict[str, dict[str, bytes]] = {}
    for role, path in role_paths.items():
        result, members = audit_zip(role, path, extraction_root)
        zip_audits[role] = result
        member_maps[role] = members

    fatal_integrity = any(x["fatal_integrity_defect"] for x in zip_audits.values())
    if fatal_integrity:
        # The supplied packets in this run are expected to pass this gate. Keep a
        # deterministic hard stop if a later run differs.
        integrity_decision = "H. NON-MATHEMATICAL PACKAGING DEFECT"
        summary = {
            "decision": integrity_decision,
            "environment": environment,
            "zip_audits": zip_audits,
        }
        json_dump(output / "verification_summary.json", summary)
        (output / "verification_log.txt").write_text(
            f"Integrity gate failed.\nDecision: {integrity_decision}\n", encoding="utf-8"
        )
        return 2

    root_obj = json.loads(member_maps["source_root"]["rotation_root_isolation.json"].decode("utf-8"))
    fixed = fixed_arithmetic_replay(root_obj)
    center_rows = parse_tsv(member_maps["source_root"]["center_120dp.tsv"].decode("utf-8"))
    polynomial = polynomial_system_audit(
        member_maps["source_root"]["rotation_polynomial_system.txt"].decode("utf-8"),
        center_rows,
    )

    # Matrix/indexing declarations and basic dimensions.
    schema_checks: dict[str, Any] = {}
    schema_checks["root_center"] = {
        "rows": len(center_rows),
        "indices": [int(row["index"]) for row in center_rows],
        "index_sequence_zero_based": [int(row["index"]) for row in center_rows] == list(range(37)),
        "common_radius": sorted(set(row["radius"] for row in center_rows)),
    }
    approx_A_rows = [
        line.split("\t")
        for line in member_maps["source_root"]["approx_inverse_A_100dp.tsv"].decode("utf-8").splitlines()
        if line.strip()
    ]
    schema_checks["approx_inverse_A"] = {
        "row_count": len(approx_A_rows),
        "column_counts": sorted(set(len(row) for row in approx_A_rows)),
        "is_37_by_37": len(approx_A_rows) == 37 and all(len(row) == 37 for row in approx_A_rows),
    }

    active_S_rows = parse_tsv(member_maps["source_active"]["selected_S_rational.tsv"].decode("utf-8"))
    schema_checks["selected_S_rational"] = check_matrix_index_grid(active_S_rows, 15)
    K_L14_rows = parse_tsv(member_maps["source_full_primal"]["K_L14_rational.tsv"].decode("utf-8"))
    schema_checks["K_L14_rational"] = check_matrix_index_grid(K_L14_rows, 14)
    finite_rows = parse_tsv(member_maps["source_full_primal"]["finite_constraints_44.tsv"].decode("utf-8"))
    state_rows = parse_tsv(member_maps["source_full_primal"]["state_matrix_table.tsv"].decode("utf-8"))
    schema_checks["finite_constraints"] = {
        "witness_rows": len(finite_rows),
        "scalar_inequalities": 2 * len(finite_rows),
        "expected_22_witnesses_44_inequalities": len(finite_rows) == 22,
        "columns": list(finite_rows[0].keys()) if finite_rows else [],
    }
    schema_checks["state_matrix_table"] = {
        "rows": len(state_rows),
        "expected_sixteen": len(state_rows) == 16,
        "matrix_names": [row["matrix"] for row in state_rows],
    }

    source_members = {
        role: member_maps[role]
        for role in ("source_primal", "source_root", "source_active", "source_full_primal")
    }
    source_functional = source_functional_completeness(
        source_members, member_maps["candidate_final"]
    )

    canonical_schema = {
        "schema_version": "clean-room-audit-1",
        "indexing": "zero-based",
        "matrix_storage": {
            "rational_matrices": "dense TSV row,col,value_decimal_rational",
            "interval_matrices": "dense TSV row,col,lower,upper",
            "symmetric_completion": "full dense storage; symmetry required explicitly",
        },
        "root_system": {
            "variables": polynomial["variables"],
            "variable_count": polynomial["variable_count"],
            "equation_count": polynomial["equation_count"],
            "center_radius": schema_checks["root_center"]["common_radius"],
        },
        "fixed_arithmetic": {
            "u": fixed["u"],
            "v": fixed["v"],
            "H2": fixed["H2"],
            "delta": fixed["delta_regenerated"],
            "R_H": fixed["R_H_regenerated"],
            "transition_automaton": fixed["automaton_regenerated"],
        },
        "matrices": {
            "state_matrix_names": schema_checks["state_matrix_table"]["matrix_names"],
            "K_L14_dimension": 14,
            "K_L15_dimension": 15,
            "K_U14_dimension": 14,
            "K_U15_dimension": 15,
        },
        "finite_constraints": {
            "witness_count": len(finite_rows),
            "inequality_count": 2 * len(finite_rows),
            "witness_order": [row["witness"] for row in finite_rows],
        },
        "source_object_availability": {
            "exact_source_functional_in_first_four_packets": source_functional["complete"],
            "candidate_final_source_functional_present": (
                "source_functional.json" in member_maps["candidate_final"]
            ),
        },
        "schema_checks": schema_checks,
    }
    json_dump(output / "canonical_schema.json", canonical_schema)

    # Required audit tables are emitted even though mathematical regeneration halts.
    with (output / "regenerated_state_table.tsv").open("w", encoding="utf-8", newline="") as f:
        fields = ["matrix", "dimension", "packet_claim_status", "clean_room_status", "reason"]
        writer = csv.DictWriter(f, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for row in state_rows:
            writer.writerow({
                "matrix": row["matrix"],
                "dimension": row["dimension"],
                "packet_claim_status": row["status"],
                "clean_room_status": "NOT_REGENERATED",
                "reason": "Decision G source-completeness halt before primal replay",
            })

    with (output / "regenerated_finite_slacks.tsv").open("w", encoding="utf-8", newline="") as f:
        fields = [
            "witness", "N", "D1", "D2", "D3", "D4", "D5",
            "clean_room_lower_status", "clean_room_upper_status", "reason"
        ]
        writer = csv.DictWriter(f, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for row in finite_rows:
            writer.writerow({
                "witness": row["witness"], "N": row["N"],
                "D1": row["D1"], "D2": row["D2"], "D3": row["D3"],
                "D4": row["D4"], "D5": row["D5"],
                "clean_room_lower_status": "NOT_REGENERATED",
                "clean_room_upper_status": "NOT_REGENERATED",
                "reason": "Decision G source-completeness halt before finite-slack replay",
            })

    stationarity_dir = output / "stationarity_reductions"
    stationarity_dir.mkdir()
    json_dump(stationarity_dir / "NOT_RUN.json", {
        "status": "NOT RUN",
        "reason": "Exact source functional is not independently recoverable from the four source packets.",
        "candidate_final_not_accepted_as_proof": True,
    })
    uniqueness_dir = output / "uniqueness_rank_certificate"
    uniqueness_dir.mkdir()
    json_dump(uniqueness_dir / "NOT_RUN.json", {
        "status": "NOT RUN",
        "reason": "Audit halted with Decision G before uniqueness replay.",
    })
    json_dump(output / "support_geometry_audit.json", {
        "status": "NOT RUN",
        "reason": "Audit halted with Decision G before support-geometry replay.",
    })

    bounds = {
        "packet_integrity": {
            role: {
                "top_level_sha256": audit["top_level_sha256"],
                "top_level_hash_match": audit["top_level_hash_match"],
                "member_count": audit["member_count"],
                "sha256sums_mismatches": audit["sha256sums_audit"]["mismatches"],
                "json_manifest_mismatches": audit["json_manifest_audit"]["mismatches"],
            }
            for role, audit in zip_audits.items()
        },
        "fixed_arithmetic": fixed,
        "root_polynomial_parse": polynomial,
        "source_functional_completeness": source_functional,
        "later_bounds": "NOT REGENERATED because Decision G was triggered",
    }
    json_dump(output / "regenerated_bounds.json", bounds)

    discrepancies = [
        {
            "severity": "fatal-for-full-certificate",
            "category": "source-data omission",
            "object": "S",
            "finding": "Exact S occurs only in candidate-final/source_functional.json.",
        },
        {
            "severity": "fatal-for-full-certificate",
            "category": "source-data omission",
            "object": "G0",
            "finding": "Exact G0 occurs only in candidate-final/source_functional.json.",
        },
        {
            "severity": "fatal-for-full-certificate",
            "category": "non-independent objective reconstruction",
            "object": "rho(c)",
            "finding": (
                "The first four packets do not uniquely determine the exact functional "
                "(G0 + E dot c)/S; final candidate data would be the sole source."
            ),
        },
    ]

    duplicate_content = {
        role: audit["duplicate_content_groups"] for role, audit in zip_audits.items()
    }
    summary = {
        "decision": DECISION,
        "formal_certificate_mathematically_supported": False,
        "clean_room_scope": (
            "Integrity, canonical parsing, exact fixed arithmetic, and automaton "
            "reconstruction completed. The audit stopped at exact source-functional "
            "reconstruction, before root inclusion and all downstream certificate stages."
        ),
        "environment": environment,
        "zip_audits": zip_audits,
        "duplicate_content_detected": duplicate_content,
        "canonical_schema_status": {
            "constructed": True,
            "schema_checks": schema_checks,
        },
        "fixed_arithmetic_status": fixed,
        "polynomial_system_status": polynomial,
        "source_functional_status": source_functional,
        "discrepancies": discrepancies,
        "not_run_stages": [
            "Krawczyk and independent interval-Newton inclusion",
            "active completion",
            "sixteen-state positivity and nullity replay",
            "44 finite inequalities",
            "dual weights and stationarity",
            "complementary slackness",
            "programmatic Lagrangian and primal-dual equality",
            "target uniqueness",
            "Schur induction",
            "support geometry",
            "two-path consistency",
        ],
    }
    json_dump(output / "verification_summary.json", summary)

    requirements = (
        f"Python=={platform.python_version()}\n"
        "# External packages: none\n"
        "# Exact integer backend: CPython int\n"
        "# Exact rational backend: fractions.Fraction\n"
        "# Decimal backend: decimal.Decimal\n"
        "# Interval backend: not initialized; Decision G source gate\n"
    )
    (output / "requirements-lock.txt").write_text(requirements, encoding="utf-8")

    # Copy the complete verifier source into the output packet.
    shutil.copy2(Path(__file__).resolve(), output / "verify_global_certificate.py")

    statuses = {
        "Clean-room directory created": "YES",
        "No hidden build artifacts used": "YES",
        "All five top-level hashes verified": "YES",
        "All internal manifests verified": "YES",
        "Canonical schema constructed": "YES",
        "Fixed arithmetic independently verified": "YES" if fixed["verified"] else "NO",
        "Automaton independently reconstructed": "YES" if fixed["automaton_exact_match"] else "NO",
        "Source functional independently verified": (
            "NO — exact S and G0 are absent from the four source packets"
        ),
        "Rotation polynomial system parsed": "YES (37 variables, 37 equations)",
        "Krawczyk inclusion regenerated": "NOT RUN — Decision G halt",
        "Independent interval-Newton check": "NOT RUN — Decision G halt",
        "Root uniqueness independently verified": "NOT RUN — Decision G halt",
        "Active completion reconstructed from S": "NOT RUN — Decision G halt",
        "Active kernel identities independently verified": "NOT RUN — Decision G halt",
        "All sixteen state matrices regenerated": "NOT RUN — Decision G halt",
        "All interval positivity proofs regenerated": "NOT RUN — Decision G halt",
        "Only two intended singular matrices found": "NOT RUN — Decision G halt",
        "Both nullities independently verified": "NOT RUN — Decision G halt",
        "All 44 finite slacks regenerated": "NOT RUN — Decision G halt",
        "w_3 ambiguity resolved": "NOT RUN — Decision G halt",
        "Dual weights independently reconstructed": "NOT RUN — Decision G halt",
        "K-stationarity symbolically verified": "NOT RUN — Decision G halt",
        "All five c-stationarity reductions verified": "NOT RUN — Decision G halt",
        "Complementary slackness independently verified": "NOT RUN — Decision G halt",
        "Complete Lagrangian generated programmatically": "NOT RUN — Decision G halt",
        "Dual constant independently derived": "NOT RUN — Decision G halt",
        "Primal-dual equality independently verified": "NOT RUN — Decision G halt",
        "Objective interval regenerated": "NOT RUN — Decision G halt",
        "Target uniqueness independently verified": "NOT RUN — Decision G halt",
        "Auxiliary-completion dimensions verified": "NOT RUN — Decision G halt",
        "Schur induction mechanically checked": "NOT RUN — Decision G halt",
        "Support geometry programmatically checked": "NOT RUN — Decision G halt",
        "Two-path consistency checks passed": "NO — downstream stages not run",
        "Executable verifier created": "YES",
        "Clean-room verification ZIP created": "YES",
        "Formal certificate mathematically supported": "NO",
    }
    first_output = write_required_first_output(
        output / "verification_log.txt", statuses, DECISION
    )
    with (output / "verification_log.txt").open("a", encoding="utf-8") as log:
        log.write("\nENVIRONMENT\n")
        log.write(json.dumps(environment, indent=2, sort_keys=True))
        log.write("\n\nINTEGRITY AUDIT\n")
        for role, audit in zip_audits.items():
            log.write(
                f"{role}: hash={audit['top_level_sha256']} "
                f"members={audit['member_count']} "
                f"fatal_integrity_defect={audit['fatal_integrity_defect']}\n"
            )
            if audit["duplicate_content_groups"]:
                log.write(
                    f"  duplicate content groups: "
                    f"{json.dumps(audit['duplicate_content_groups'], sort_keys=True)}\n"
                )
        log.write("\nFIXED ARITHMETIC\n")
        log.write(json.dumps(fixed, indent=2, sort_keys=True))
        log.write("\n\nROOT POLYNOMIAL PARSE\n")
        log.write(json.dumps(polynomial, indent=2, sort_keys=True))
        log.write("\n\nSOURCE-FUNCTIONAL COMPLETENESS GATE\n")
        log.write(json.dumps(source_functional, indent=2, sort_keys=True))
        log.write("\n\nDISCREPANCIES\n")
        log.write(json.dumps(discrepancies, indent=2, sort_keys=True))
        log.write(f"\n\nDecision: {DECISION}\n")

    # Human-readable verifier manifest for the non-circular output set.
    manifest_rows = []
    for file_path in sorted(p for p in output.rglob("*") if p.is_file()):
        rel = file_path.relative_to(output).as_posix()
        manifest_rows.append({
            "path": rel,
            "bytes": file_path.stat().st_size,
            "sha256": sha256_file(file_path),
        })
    with (output / "verifier_manifest.tsv").open("w", encoding="utf-8", newline="\n") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "bytes", "sha256"], delimiter="\t")
        writer.writeheader()
        writer.writerows(manifest_rows)

    # Produce hashes for all output files except SHA256SUMS.txt itself.
    output_hash_rows = []
    for file_path in sorted(p for p in output.rglob("*") if p.is_file()):
        rel = file_path.relative_to(output).as_posix()
        output_hash_rows.append((sha256_file(file_path), rel))
    with (output / "SHA256SUMS.txt").open("w", encoding="utf-8", newline="\n") as f:
        for digest, rel in output_hash_rows:
            f.write(f"{digest}  {rel}\n")

    # Deterministic archive: sorted entries, fixed timestamp, fixed permissions.
    archive_path = output.parent / "clean_room_global_certificate_verification.zip"
    if archive_path.exists():
        archive_path.unlink()
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for file_path in sorted(p for p in output.rglob("*") if p.is_file()):
            rel = file_path.relative_to(output).as_posix()
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 & 0xFFFF) << 16
            info.create_system = 3
            zf.writestr(info, file_path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    archive_hash = sha256_file(archive_path)
    hash_sidecar = archive_path.with_suffix(archive_path.suffix + ".sha256")
    hash_sidecar.write_text(f"{archive_hash}  {archive_path.name}\n", encoding="utf-8")
    print(first_output, end="")
    print(f"Output ZIP SHA-256: {archive_hash}")
    print(f"Output ZIP: {archive_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
