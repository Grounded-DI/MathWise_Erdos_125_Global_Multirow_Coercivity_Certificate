Exact Source-Functional Source Packet

Purpose
-------
The preceding clean-room audit halted because exact S and G0 were absent from the
four non-candidate source packets. This packet supplies the complete exact source
functional as fixed problem-instance data.

Provenance
----------
The constants were read directly from the source-repair prompt. The candidate-final
packet was not used as the source of these values. This packet records problem input,
not proof conclusions.

Parsing
-------
Numerators and denominators are decimal integer strings. Parse them into arbitrary-
precision integers and exact rationals. Do not route values through binary64.

Created UTC: 2026-07-19T06:02:57+00:00
Previous verifier source SHA-256: 8fddade0ac56ca90a3f632292a5caf2fb0e2fb72bf1d0249254dae40193609ba
